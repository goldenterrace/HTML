var canvas = document.getElementById('myCanvas');
var ctx = canvas.getContext('2d');

/*canvas绘制*/
draw();
function draw() {
    document.onmousedown = function (e) {
        var oEvent = e || window.event;
        ctx.beginPath();
        ctx.strokeStyle = "white";
        ctx.lineWidth = 4;
        ctx.moveTo(oEvent.clientX - canvas.offsetLeft, oEvent.clientY - canvas.offsetTop);
        document.onmousemove = function (e) {
            var oEvent = e || window.event;
            oEvent.preventDefault();
            ctx.lineTo(oEvent.clientX - canvas.offsetLeft, oEvent.clientY - canvas.offsetTop);
            ctx.stroke();
        };
        document.onmouseup = function () {
            document.onmousemove = null;
            document.onmouseup = null;
            ctx.closePath();
        }
    };
}

var img1=document.getElementById("img1");
var oHero=document.getElementById("hero");

/*完成绘制*/
function saveCanvas(){
    img1.src=canvas.toDataURL();
    oHero.src=canvas.toDataURL();
}

/*清除画布*/
function clearCanvas(){
    ctx.clearRect(0, 0, 197, 197);
}

/*页面切换*/
var oLogin = document.getElementById("login");
var oGame = document.getElementById("game");
function change(){
    oLogin.style.transform = "translateY(-600px)";
    oGame.style.transform = "translateY(-600px)";
}

/*hero跳跃函数*/
var bFlag = true;
var timer_hero = null;
function heroJump(){
    clearInterval(timer_hero);
    timer_hero = setInterval(function(){
        var heroTop = oHero.offsetTop;
        if(bFlag){
            heroTop-=30;
        }else{
            heroTop+=30;
        }

        oHero.style.top = heroTop+"px";

        if(heroTop < 100){
            bFlag = false;
        }
        else if(heroTop > 400){
            bFlag = true;
            clearInterval(timer_hero);

        }
    },30)
}

/*键盘操作*/
var keypressed={};
function keyPressTrue(e){
    keypressed[e.keyCode] = true;
}
function keyPressFalse(e){
    keypressed[e.keyCode] = false;
}

document.addEventListener("keydown",keyPressTrue);
document.addEventListener("keyup",keyPressFalse);
var timer_hero_move = null;
var oGamebg = document.getElementById("gamebg")
function heroMove(){
    timer_hero_move = setInterval(
        function(){
            /*向左移动*/
            if(keypressed[37]){
                oHero.style.left = oHero.offsetLeft-10+"px";
                if(oHero.offsetLeft < 0 ){
                    oHero.style.left = 0+"px";/*当英雄移动到最左边缘（这个最左边缘就是第一页login的最左边）不在移动，防止它再次移动出现超过这个界面的情况*/
                }

            }
            /*向右移动*/
            if(keypressed[39]){

                if(oHero.offsetLeft < 528){
                    oHero.style.left = oHero.offsetLeft+10+"px";
                }else{
                    oGamebg.style.left = oGamebg.offsetLeft-10+"px";
                }

                if(oGamebg.offsetLeft < -2072){
                    oGamebg.style.left = -2072+"px";/*防止游戏背景页面一直向左移动，后面就没有图片了，就设置游戏背景页面移动到一定距离的时候，让游戏背景处于一个固定的位置不在移动*/
                    oHero.style.left = oHero.offsetLeft+10+"px";
                    /*当hero移动到最右端（这个最右端就是第二页game的右边缘）不在移动，同时出现游戏胜利的图片*/
                    if(oHero.offsetLeft > 840){
                        oHero.style.left = 840+"px";
                        oGameEnd.src = "img/win.png";/*改变元素的图片路径，达到切换不同图片的结果*/
                        oGameEnd.style.opacity=1;
                    }
                }


            }
            /*向上移动*/
            if(keypressed[38]){
                heroJump()
            }
        },33);
}


var oGameEnd = document.getElementById("GameEnd");
var oMonster=document.getElementById("monster");
var MFlag = true;
var timer_monster = null;
function monsterMove(){
    clearInterval(timer_monster);
    timer_monster = setInterval(function(){
        var monsterLeft = oMonster.offsetLeft;
        if (monsterLeft < 250) {
            MFlag = false;
        }
        else if (monsterLeft > 700) {
            MFlag = true;
        }
        /*怪物向左*/
        if (MFlag) {
            monsterLeft -= 10;
        }
        /*怪物向右*/
        else {
            monsterLeft += 10;
        }
        oMonster.style.left = monsterLeft + "px";


        if (isCrash(oHero, oMonster) == true) {
            /*撞击了就关闭hero移动函数和怪物移动函数*/
            clearInterval(timer_monster);
            clearInterval(timer_hero_move);
            oGameEnd.src ="img/GameOver.png";/*切换游戏失败的图片*/
            oGameEnd.style.opacity=1;
        }
    },33)
}

/*碰撞函数*/
function isCrash (obj1,obj2) {

    var boolCrash = true;

    /*使用getBoundingClientRect()的原因是，将hero和monster放在同一个参考系上面，这样方便通过他们的left或者top值来进行比较*/

    var left1 = obj1.getBoundingClientRect().left;/*getBoundingClientRect().left  获取元素相对浏览器的左边缘之间的距离*/

    var right1 = obj1.getBoundingClientRect().right;

    var top1 = obj1.getBoundingClientRect().top;/*getBoundingClientRect().left  获取元素相对浏览器的上边缘之间的距离*/

    var bottom1 = obj1.getBoundingClientRect().bottom;

    var left2 = obj2.getBoundingClientRect().left;

    var right2 = obj2.getBoundingClientRect().right;

    var top2 = obj2.getBoundingClientRect().top;

    var bottom2 = obj2.getBoundingClientRect().bottom;


    if (right1 > left2 && left1 < right2 && bottom1 > top2 && top1 < bottom2) {
        boolCrash = true;
    } else{
        boolCrash = false;
    }
    return boolCrash;
}


/*开始按钮函数*/
var oStart = document.getElementById("GameStart");
oStart.onclick = start;
function start(){
    monsterMove();
    heroMove();
    oStart.style.display = "none";
}