//全选事件
function myClick1(){
    var aitems = document.getElementsByClassName("item1");
    for(var i = 0;i < aitems.length;i++){
        if(document.getElementById("check_all1").checked==true){
            aitems[i].checked = true;
        }else{
            aitems[i].checked = false;
        }
    }
}

function myClick2(){
    var aitems = document.getElementsByClassName("item2");
    for(var i = 0;i < aitems.length;i++){
        if(document.getElementById("check_all2").checked==true){
            aitems[i].checked = true;
        }else{
            aitems[i].checked = false;
        }
    }
}
//弹药库到背包
function add(){
    var ary = [];
    var aitems = document.getElementsByClassName("item2");
    for(var i = 0;i < aitems.length;i++){
        if(aitems[i].checked){
            ary[i] = aitems[i].parentNode.parentNode.rowIndex;//保存下所选行的索引
            moveToLeft(aitems[i].value);
        }
    }
    /*移除掉添加到背包的一行*/
    for(var i = ary.length-1;i >=0;i--){
        var oRightTbody = document.getElementById("tab_right");

        //判断数组ary里的值是不是行索引
        if(!isNaN(ary[i])){
            oRightTbody.deleteRow(ary[i]-1);
            //移除表格的所选行
        }
    }
    document.getElementById("check_all2").checked = false;
    //全选复选框置为false
}


/*移除弹药库，添加到背包*/
function moveToLeft(op){
    var item_number = document.getElementById("id"+op).value;
    var item_name = document.getElementById("name"+op).value;

    var oLeftTbody = document.getElementById("tab_left");
    var tr = document.createElement("tr");
    var td1 = document.createElement("td");
    var td2 = document.createElement("td");
    var td3 = document.createElement("td");
    var td4 = document.createElement("td");

    td1.innerHTML = "<input type='checkbox' class='item1' value='"+item_number+"'>";
    td2.innerHTML = "<input type='text' id='id"+item_number+"' value='"+item_number+"'>";
    td3.innerHTML = "<input type='text' id='name"+item_number+"' value='"+item_name+"'>";
    td4.innerHTML = "<img  src='"+item_number+".png'>";

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    oLeftTbody.appendChild(tr);
}



/*背包到弹药库*/
function remove(){
    var ary1 = [];
    var aitems = document.getElementsByClassName("item1");
    for(var i = 0;i < aitems.length;i++){
        if(aitems[i].checked){
            //先保存所选行的索引 在移除掉所选行
            ary1[i] = document.getElementById("id"+aitems[i].value).parentNode.parentNode.rowIndex;
            //保存下所选行的索引
            moveToRight(aitems[i].value);//移值
        }
    }
    for(var i = ary1.length;i >0;i--){
        var oRightTbody = document.getElementById("tab_left");

        //判断数组ary里的值是不是行索引
        if(!isNaN(ary1[i-1])){
            oRightTbody.deleteRow(ary1[i-1]-1);
            //移除表格的所选行
        }
    }
    document.getElementById("check_all1").checked = false;
    //全选复选框置为false
}

/*移除背包，返回到弹药库*/
function moveToRight(op) {
    var item_number = document.getElementById("id" + op).value;
    var item_name = document.getElementById("name" + op).value;
    var oRightTbody = document.getElementById("tab_right");

    var tr = document.createElement("tr");
    var td1 = document.createElement("td");
    var td2 = document.createElement("td");
    var td3 = document.createElement("td");
    var td4 = document.createElement("td");

    td1.innerHTML = "<input type='checkbox'  class='item2' value='" + item_number + "'>";
    td2.innerHTML = "<input type='text' id='id" + item_number + "' value='" + item_number + "'>";
    td3.innerHTML = "<input type='text' id='name" + item_number + "' value='" + item_name + "'>";
    td4.innerHTML = "<img  src='"+item_number+".png'>";

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    oRightTbody.appendChild(tr);
}